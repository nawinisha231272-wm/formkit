const fs = require('fs');
class Steps {
  onTestBegin(test) { this.started=Date.now(); this.rows=[]; this.test=test.title; }
  onStepBegin(test,result,step) { step._began=Date.now(); }
  onStepEnd(test,result,step) { this.rows.push({category:step.category,title:step.title,ms:Date.now()-step._began,error:step.error?.message}); }
  onTestEnd(test,result) { fs.appendFileSync(process.env.PROFILE_STEPS,JSON.stringify({test:this.test,ms:Date.now()-this.started,status:result.status,steps:this.rows})+'\n'); }
}
module.exports=Steps;
