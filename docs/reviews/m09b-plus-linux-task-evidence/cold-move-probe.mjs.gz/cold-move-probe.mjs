import { chromium, expect } from '@playwright/test';
const browser = await chromium.launch();
const page = await browser.newPage();
let release;
const held = new Promise(resolve => { release=resolve; });
let intercepted = false;
await page.route(/\/features\/bulk-plan\.js(?:\?.*)?$/, async route => {
  intercepted=true;
  await held;
  await route.continue();
});
const state = () => page.evaluate(() => ({
  order:window.miniBuilder.builder.getState().definition.components.map(n=>n.id),
  history:window.miniBuilder.builder.getState().history.past.length,
  selected:[...document.querySelectorAll('.of-builder-outline [data-drag-id][aria-selected=true]')].map(n=>n.dataset.dragId),
}));
try {
  await page.goto('http://127.0.0.1:4173/builder.html?empty&settingsPreload=none');
  await page.evaluate(() => window.nestedBuilder.load({$formVersion:'1.0',id:'move-block',display:'form',components:['a','b','c','d'].map(id=>({id,type:'text',key:id,label:id}))}));
  await page.locator('.of-builder-outline [role=treeitem][data-drag-id="b"]').focus();
  await page.keyboard.press('Shift+ArrowDown');
  const before=await state();
  await page.keyboard.press('Alt+ArrowDown');
  const immediate=await state();
  await expect(page.getByRole('dialog',{name:'Preparing selected components',exact:true})).toBeVisible();
  expect(immediate.order).toEqual(['a','b','c','d']);
  expect(immediate.history).toBe(before.history);
  release();
  await expect.poll(async ()=>(await state()).order).toEqual(['a','d','b','c']);
  const completed=await state();
  expect(completed.history).toBe(before.history+1);
  expect(completed.selected).toEqual(['b','c']);
  console.log(JSON.stringify({intercepted,before,immediate,completed,conclusion:'The approved lazy Move completes after its import; the legacy immediate schema read can precede completion.'},null,2));
} finally {
  release();
  await browser.close();
}
