import { webkit } from "../../node_modules/@playwright/test/index.mjs";
import { createServer } from "node:http";
import { execFileSync } from "node:child_process";
import { mkdir,writeFile,readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { setTimeout as sleep } from "node:timers/promises";
const out=resolve(".git/ourform-owner-proof-2026-11-06/display");await mkdir(out,{recursive:true});
const display=()=>{
 const log=execFileSync("pmset",["-g","log"],{maxBuffer:64*1024*1024}).toString("utf8");
 const last=log.split("\n").filter(line=>/Display is turned (on|off)/.test(line)).at(-1)??"";
 return {source:"pmset display notification",event:last.slice(0,19),asleep:last.includes("Display is turned off")};
};
function pids(){
 const rows=new Map(execFileSync("ps",["-axo","pid=,ppid=,comm="],{encoding:"utf8"}).split("\n").flatMap(line=>{const m=line.trim().match(/^(\d+)\s+(\d+)\s+(.+)$/);return m?[[Number(m[1]),{parent:Number(m[2]),command:m[3]}]]:[];}));
 const owned=pid=>{const seen=new Set();while(rows.has(pid)&&!seen.has(pid)){if(pid===process.pid)return true;seen.add(pid);pid=rows.get(pid).parent;}return false;};
 return [...rows].filter(([pid,row])=>row.command.endsWith("/Playwright.app/Contents/MacOS/Playwright")&&owned(pid)).map(([pid])=>pid);
}
const threads=pid=>execFileSync("ps",["-M",String(pid)],{encoding:"utf8"}).trim().split("\n").length-1;
let requests=0;
const server=createServer((_,response)=>{requests++;response.writeHead(200,{"content-type":"text/html"});response.end("<!doctype html><title>Probe</title><h1>ok</h1>");});
await new Promise(resolve=>server.listen(4199,"127.0.0.1",resolve));
async function arm(name,fixed){
 const before=new Set(pids());const browser=await webkit.launch(fixed?{executablePath:resolve("scripts/webkit-macos.sh"),env:{...process.env,OURFORM_PINNED_WEBKIT_EXECUTABLE:webkit.executablePath()}}:{});
 const pid=pids().find(p=>!before.has(p));if(!pid)throw new Error("Owned browser PID missing");
 const result={name,start:new Date().toISOString(),pid,display:display(),startThreads:threads(pid),pages:[],completed:0,failed:false};
 try{
  for(let i=0;i<200;i++){
   const context=await browser.newContext();let seen=0;const beforeRequests=requests;const at=performance.now();
   try{
    const page=await Promise.race([context.newPage(),sleep(15000,undefined,{ref:false}).then(()=>{throw new Error("newPage observation timeout");})]);
    page.on("request",()=>seen++);await page.goto("http://127.0.0.1:4199/"+i,{timeout:15000});result.completed++;
    if(i%10===0){const row={i,ms:performance.now()-at,threads:threads(pid),display:display()};result.pages.push(row);console.log(JSON.stringify({name,...row}));}
   }catch(error){
    result.failed=true;result.failure={i,error:String(error),seen,serverRequests:requests-beforeRequests,threads:threads(pid),display:display()};
    const at=performance.now(),response=await fetch("http://127.0.0.1:4199/probe");result.failure.externalProbe={status:response.status,milliseconds:performance.now()-at,body:await response.text()};
    execFileSync("sample",[String(pid),"2","-file",out+"/"+name+"-sample.txt"],{stdio:"pipe"});const sample=await readFile(out+"/"+name+"-sample.txt","utf8");result.failure.animationBlocked=sample.includes("NSAnimation")&&sample.includes("_runBlocking");console.log(JSON.stringify({name,failure:result.failure}));break;
   }
   await context.close();
  }
  result.endThreads=threads(pid);result.endDisplay=display();
 }finally{
  result.end=new Date().toISOString();await writeFile(out+"/"+name+".json",JSON.stringify(result,null,2)+"\n");
  if(result.failed){try{process.kill(pid,"SIGTERM");}catch{}}
  await Promise.race([browser.close().catch(()=>{}),sleep(3000,undefined,{ref:false})]);
 }
 return result;
}
try{
 if(!display().asleep)throw new Error("Control requires the display asleep");
 const baseline=await arm("baseline",false),fixed=await arm("fixed",true);
 const confirmed=baseline.failed&&baseline.failure.seen===0&&baseline.failure.serverRequests===0&&baseline.failure.externalProbe.status===200&&baseline.failure.animationBlocked&&fixed.completed===200&&!fixed.failed&&fixed.display.asleep&&fixed.endDisplay.asleep&&fixed.pages.every(p=>p.display.asleep);
 const result={status:confirmed?"CONFIRMED":"NOT_CONFIRMED",baselineCompleted:baseline.completed,fixedCompleted:fixed.completed,baselineThreads:[baseline.startThreads,baseline.endThreads],fixedThreads:[fixed.startThreads,fixed.endThreads]};
 await writeFile(out+"/status.json",JSON.stringify(result,null,2)+"\n");console.log(JSON.stringify(result));
 if(!confirmed)process.exitCode=1;
}finally{server.close();}
