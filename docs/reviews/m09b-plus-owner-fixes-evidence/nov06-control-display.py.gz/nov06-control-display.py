from pathlib import Path
import subprocess,os,signal,re,json,datetime
root=Path(".git/ourform-owner-proof-2026-11-06");(root/"display").mkdir(exist_ok=True)
s=subprocess.check_output(["ioreg","-r","-c","IOHIDSystem","-d","1"]).decode("utf8",errors="replace")
m=re.search(r'"HIDIdleTime"\s*=\s*(\d+)',s);idle=int(m[1])/1e9 if m else 0
assert idle>600,"Do not interrupt an active user"
prefs=subprocess.check_output(["pmset","-g","custom"],text=True)
record={"start":datetime.datetime.now(datetime.timezone.utc).isoformat(),"physicalIdleSeconds":idle,"powerPreferencesBefore":prefs}
try:
 subprocess.run(["pmset","displaysleepnow"],check=True)
 command=["npx","--offline","--yes","--package=node@22.22.3","--package=pnpm@10.10.0","pnpm","exec","node",str(root/"display-probe.mjs")]
 with (root/"display/control.log").open("w") as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:record["exit"]=child.wait(timeout=480)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGTERM);record["exit"]="observation limit"
finally:
 subprocess.run(["caffeinate","-u","-t","2"],check=True)
 record["wakeRequested"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record["powerPreferencesAfter"]=subprocess.check_output(["pmset","-g","custom"],text=True)
 record["powerPreferencesUnchanged"]=record["powerPreferencesBefore"]==record["powerPreferencesAfter"]
 (root/"display/hardware-control.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
