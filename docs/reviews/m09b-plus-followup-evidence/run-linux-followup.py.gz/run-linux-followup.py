import subprocess,json
from pathlib import Path
p=Path('.git/ourform-owner-followup-2026-11-09')
# The AB process must finish before any correctness/build work starts.
subprocess.run(['docker','exec','ourform-linux-profile','bash','-lc','while kill -0 611 2>/dev/null; do sleep 3; done'],check=True)
for f in ['packages/builder/src/canvas.ts','tests/e2e/builder-loading.spec.ts','tests/e2e/builder-hosts.spec.ts','tests/e2e/builder-bulk-actions.spec.ts','tests/work-counts/runtime-styles.spec.ts']:
 subprocess.run(['docker','cp',f,'ourform-linux-profile:/work/branch/'+f],check=True)
for f,remote in [('linux-followup.sh','owner-followup.sh'),('linux-x64-grep','owner-linux-grep')]:
 subprocess.run(['docker','cp',str(p/f),'ourform-linux-profile:/tmp/'+remote],check=True)
r=subprocess.run(['docker','exec','ourform-linux-profile','bash','/tmp/owner-followup.sh'])
for remote,local in [('owner-counts.log','linux-counts.log'),('owner-captures.log','linux-captures.log'),('owner-targeted.log','linux-targeted.log'),('owner-size.json','linux-size.json'),('owner-size.err','linux-size.err')]:
 subprocess.run(['docker','cp','ourform-linux-profile:/tmp/'+remote,str(p/local)])
if r.returncode: raise SystemExit(r.returncode)
for f in json.loads((p/'requested-images.json').read_text()):
 if '/linux-x64/' in f:subprocess.run(['docker','cp','ourform-linux-profile:/work/branch/'+f,f],check=True)
(p/'linux-status').write_text('PASS\n')
