import {createRequire} from 'node:module';import {dirname,join} from 'node:path';import{readFileSync,writeFileSync}from'node:fs';import{execFileSync}from'node:child_process';import{createHash}from'node:crypto';
const require=createRequire(import.meta.url);const pw=require.resolve('playwright/package.json',{paths:[dirname(require.resolve('@playwright/test/package.json'))]});const core=require.resolve('playwright-core/package.json',{paths:[dirname(pw)]});const{PNG}=require(join(dirname(core),'lib/utilsBundle.js'));
const p='.git/ourform-owner-followup-2026-11-09/';const seen=new Set(),rows=[];
for(const file of JSON.parse(readFileSync(p+'requested-images.json'))){
 const old=execFileSync('git',['show','0b3b452:'+file]);const next=readFileSync(file);const key=createHash('sha256').update(old).update(next).digest('hex');if(seen.has(key))continue;seen.add(key);
 const a=PNG.sync.read(old),b=PNG.sync.read(next);const unmatchedRows={};let unmatched=0, outsideHoverBorders=0;
 const box=file.includes('-material.png')?[41,332,533,427]:file.includes('-tailwind.png')?[41,253,533,293]:[33,245,541,285];
 const onBorder=(x,y)=>x>=box[0]-3&&x<=box[2]+3&&y>=box[1]-3&&y<=box[3]+3&&(Math.abs(x-box[0])<=3||Math.abs(x-box[2])<=3||Math.abs(y-box[1])<=3||Math.abs(y-box[3])<=3);
 for(let y=0;y<b.height;y++)for(let x=0;x<b.width;x++) {const bi=(y*b.width+x)*4;let match=false;for(let dy=-1;dy<=1&&!match;dy++)for(let dx=-1;dx<=1&&!match;dx++){const xx=x+dx,yy=y+dy;if(xx<0||yy<0||xx>=a.width||yy>=a.height)continue;const ai=(yy*a.width+xx)*4;let difference=0;for(let c=0;c<3;c++)difference+=Math.abs(a.data[ai+c]-b.data[bi+c]);if(difference<=90)match=true;}
 if(!match){if(!onBorder(x,y))outsideHoverBorders++;unmatched++;unmatchedRows[y]=(unmatchedRows[y]??0)+1;}}
 rows.push({file,width:b.width,height:b.height,unmatched,outsideHoverBorders,hoverBorderBox:box,unmatchedRows});
}
writeFileSync(p+'raster-audit.json',JSON.stringify(rows,null,2)+'\n');console.log(rows.map(r=>({file:r.file,unmatched:r.unmatched,rows:Object.keys(r.unmatchedRows)})));
