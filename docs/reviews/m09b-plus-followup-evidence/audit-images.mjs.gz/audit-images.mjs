import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const require=createRequire(import.meta.url);
const pw=require.resolve('playwright/package.json',{paths:[dirname(require.resolve('@playwright/test/package.json'))]});
const core=require.resolve('playwright-core/package.json',{paths:[dirname(pw)]});
const {PNG}=require(join(dirname(core),'lib/utilsBundle.js'));
const dir='.git/ourform-owner-followup-2026-11-09/';
function diff(before,after) {
 const a=PNG.sync.read(before),b=PNG.sync.read(after); let count=0, left=b.width,top=b.height,right=0,bottom=0;
 if(a.width!==b.width||a.height!==b.height) return {sizeChanged:true,before:[a.width,a.height],after:[b.width,b.height]};
 const rows=new Map();
 for(let y=0;y<b.height;y++)for(let x=0;x<b.width;x++) {let i=(y*b.width+x)*4;if(a.data.subarray(i,i+4).equals(b.data.subarray(i,i+4)))continue;count++;left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);rows.set(y,(rows.get(y)??0)+1);}
 return {sizeChanged:false,width:b.width,height:b.height,count,bounds:count?{left,top,right,bottom}:null,rows:[...rows]};
}
const rows=JSON.parse(readFileSync(dir+'requested-images.json')).map(file=>{
 const after=readFileSync(file);
 return {file,previous:diff(execFileSync('git',['show','cc05111:'+file]),after),main:diff(execFileSync('git',['show','0b3b452:'+file]),after)};
});
writeFileSync(dir+'image-audit.json',JSON.stringify(rows,null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({file:r.file.split('/').slice(3).join('/'),previous:{...r.previous,rows:undefined},main:{...r.main,rows:undefined}})),null,2));
