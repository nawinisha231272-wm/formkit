import { test } from '@playwright/test';
test('record the existing virtual-slot context click target', async ({page})=>{
 await page.goto('/builder.html?fixture');
 const column=page.getByRole('treeitem',{name:'Column 2',exact:true});
 await column.locator(':scope > .of-builder-tree-name').click();
 await column.press('ArrowLeft');await column.press('ArrowRight');await column.press('ArrowRight');
 await page.evaluate(()=>document.addEventListener('contextmenu',event=>{
  const target=event.target as Element;
  const nearest=target.closest<HTMLElement>('[role="treeitem"]');
  (window as unknown as {slotProbe:unknown}).slotProbe={target:target.outerHTML,nearest:nearest?.dataset,ancestorSlot:target.closest<HTMLElement>('[data-builder-slot]')?.dataset};
 },{capture:true,once:true}));
 await column.click({button:'right'});
 console.log(JSON.stringify(await page.evaluate(()=>(window as unknown as {slotProbe:unknown}).slotProbe)));
 console.log('MENU',await page.getByRole('menu').textContent());
});
