#!/bin/bash
set -euo pipefail
cd /work/branch
export CI=true PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1
cat > playwright.owner-followup.config.ts <<'CONFIG'
import base from './playwright.config';
import { defineConfig } from '@playwright/test';
export default defineConfig({...base,webServer:Array.isArray(base.webServer)?base.webServer.slice(1,6):base.webServer});
CONFIG
pinned=(npx --yes --package=node@22.22.3 --package=pnpm@10.10.0 pnpm)
# Counts already passed 9/9 before the capture selector typo; preserve that log.
"${pinned[@]}" exec playwright test -c playwright.owner-followup.config.ts tests/e2e/builder-hosts.spec.ts --project=chromium --grep "$(cat /tmp/owner-linux-grep)" --update-snapshots=all > /tmp/owner-captures.log 2>&1
"${pinned[@]}" exec playwright test -c playwright.owner-followup.config.ts tests/e2e/builder-bulk-actions.spec.ts tests/e2e/builder-loading.spec.ts --grep 'context-click|completed command loading' > /tmp/owner-targeted.log 2>&1
"${pinned[@]}" exec node scripts/builder-size-gate.mjs > /tmp/owner-size.json 2> /tmp/owner-size.err
