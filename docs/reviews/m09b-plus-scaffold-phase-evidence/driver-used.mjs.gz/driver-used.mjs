import { spawn, execFileSync } from "node:child_process";
import { mkdtemp, mkdir, readdir, readFile, writeFile, rm, stat } from "node:fs/promises";
import { tmpdir, platform, arch } from "node:os";
import { join, resolve, relative } from "node:path";
import assert from "node:assert/strict";
const output="/tmp/ourform-scaffold-phase-evidence";
await mkdir(output,{recursive:true});
const roots={main:"/tmp/ourform-scaffold-main-20261030",branch:"/Users/dharanesh/Documents/ChatGPT/formkit-project"};
const results=[];
let sample=0;
assert.equal(execFileSync("git",["rev-parse","HEAD"],{cwd:roots.main,encoding:"utf8"}).trim(),"0b3b452c46096e852248ca11872f9697888c621e");
const env={...process.env,CI:"true",npm_config_offline:"false",PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD:"1"};
const clean=s=>s.replace(/\x1b\[[0-9;]*m/g,"");
async function run(label,args,cwd,onLine) {
 const started=performance.now();let stdout="",pending="";
 const child=spawn("pnpm",args,{cwd,env,stdio:["ignore","pipe","pipe"]});
 const consume=data=>{const text=data.toString();stdout+=text;pending+=text;let i;while((i=pending.indexOf("\n"))>=0){const line=clean(pending.slice(0,i));pending=pending.slice(i+1);onLine?.(line,performance.now()-started);}};
 child.stdout.on("data",consume);child.stderr.on("data",consume);
 const timer=setTimeout(()=>child.kill("SIGTERM"),120000);
 const code=await new Promise((res,rej)=>{child.once("error",rej);child.once("close",res);});clearTimeout(timer);
 const milliseconds=performance.now()-started;
 await writeFile(join(output,sample+"-"+label+".log"),stdout);
 assert.equal(code,0,label+" failed; see "+output);
 return {milliseconds,stdout:clean(stdout)};
}
async function inspectKit(kit,root) {
 const packages=[];
 for(const archive of await readdir(kit)){
  const path=join(kit,archive);
  const files=new Set(execFileSync("tar",["-tzf",path],{encoding:"utf8"}).split("\n"));
  const manifest=JSON.parse(execFileSync("tar",["-xOzf",path,"package/package.json"],{encoding:"utf8"}));
  const check=value=>{if(typeof value==="string"&&value.startsWith("./"))assert(files.has("package/"+value.slice(2)),archive+": "+value);else if(value&&typeof value==="object")Object.values(value).forEach(check);};
  check(manifest.exports);
  const dist=resolve(root,"packages",manifest.name.split("/")[1],"dist");
  let rawBytes=0,assets=0;
  for(const entry of await readdir(dist,{recursive:true,withFileTypes:true}))if(entry.isFile()){
   const absolute=join(entry.parentPath,entry.name),asset=relative(dist,absolute).split("\\").join("/");
   assert(files.has("package/dist/"+asset),archive+": missing "+asset);
   rawBytes+=(await stat(absolute)).size;assets++;
  }
  packages.push({name:manifest.name,archive,assets,rawBytes,tarballBytes:(await stat(path)).size});
 }
 return packages;
}
for(sample of [0,1])for(const kind of ["component","theme","plugin"])for(const [revision,root]of (sample===0?Object.entries(roots):Object.entries(roots).reverse())){
 const work=await mkdtemp(join(tmpdir(),"ourform-phases-"+revision+"-"+kind+"-"));
 const kit=join(work,"kit"),directory=join(work,kind),cache=join(work,"registry-cache");
 const record={sample,revision,kind,root,head:execFileSync("git",["rev-parse","HEAD"],{cwd:root,encoding:"utf8"}).trim(),node:process.version,platform:platform()+"-"+arch(),start:new Date().toISOString(),phases:{}};
 const started=performance.now();
 try{
  record.phases.pack=(await run(revision+"-"+kind+"-pack",["sdk:pack",kit],root)).milliseconds;
  let at=performance.now();record.packages=await inspectKit(kit,root);record.phases.exportAssetChecks=performance.now()-at;
  at=performance.now();
  execFileSync(process.execPath,[resolve(root,"packages/cli/dist/cli.js"),"create-"+kind,"sample-"+kind,"--directory",directory,"--local-packages",kit],{env,encoding:"utf8"});
  record.phases.generate=performance.now()-at;
  record.phases.install=(await run(revision+"-"+kind+"-install",["install","--prefer-offline","--cache-dir",cache],directory)).milliseconds;
  at=performance.now();await rm(join(directory,"node_modules"),{recursive:true,force:true});record.phases.removeNodeModules=performance.now()-at;
  record.phases.offlineReinstall=(await run(revision+"-"+kind+"-offline",["install","--offline","--frozen-lockfile","--cache-dir",cache],directory)).milliseconds;
  const boundaries=[];
  const verified=await run(revision+"-"+kind+"-verify",["verify"],directory,(line,at)=>{const match=line.match(new RegExp("^> sample-"+kind+"@0\\.0\\.0 (build|typecheck|test|test:browser)(?:\\s|$)"));if(match)boundaries.push({phase:match[1],at});});
  assert(verified.stdout.includes("1 passed"));assert(verified.stdout.includes("generated builder palette/undo/redo"));
  assert.deepEqual(boundaries.map(b=>b.phase),["build","typecheck","test","test:browser"]);
  record.phases.verify=verified.milliseconds;record.phases.verifyStartup=boundaries[0].at;
  for(let i=0;i<boundaries.length;i++)record.phases[boundaries[i].phase==="test"?"nodeTests":boundaries[i].phase==="test:browser"?"browser":boundaries[i].phase]=(boundaries[i+1]?.at??verified.milliseconds)-boundaries[i].at;
  record.browserTests=Number(verified.stdout.match(/Running (\d+) tests/)?.[1]);
  record.outcome="PASS";
 }catch(error){record.outcome="FAIL";record.error=String(error);throw error;}
 finally{
  const at=performance.now();await rm(work,{recursive:true,force:true});record.phases.cleanup=performance.now()-at;
  record.total=performance.now()-started;record.end=new Date().toISOString();results.push(record);
  await writeFile(join(output,"results.json"),JSON.stringify({measurement:"two counterbalanced main/branch pairs per scaffold; same host, pinned tools, fresh metadata caches; verify script unmodified",results},null,2)+"\n");
  console.log(JSON.stringify({sample,revision,kind,outcome:record.outcome,total:record.total,phases:record.phases}));
 }
}

