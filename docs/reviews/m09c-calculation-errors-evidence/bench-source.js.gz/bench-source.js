import {createEngine} from '@ourform/core';
import {builtinComponents} from '@ourform/components';
import {mount} from '@ourform/renderer-dom';
import {baseTheme} from '@ourform/themes/base';
const engine=createEngine();
for(const field of builtinComponents)engine.register(field.model);
const views=new Map(builtinComponents.map(f=>[f.model.type,f.views]));
const root=document.querySelector('#form');
const median=values=>[...values].sort((a,b)=>a-b)[Math.floor(values.length/2)];
window.run=(count,kind)=>{
 const definition={$formVersion:'1.0',id:'comparison',display:'form',settings:{validateOn:'change'},components:Array.from({length:count},(_,i)=>({id:`field-${i}`,key:`field${i}`,type:'text',label:`Field ${i+1}`,...(kind==='legacy'&&i>0&&i<=25?{calculate:{expr:['concat',{ref:'field-0'},`-${i}`]},visibleWhen:['neq',{ref:'field-0'},'hidden'],disabledWhen:['eq',{ref:'field-0'},'disabled']}: {})}))};
 const samples=[];
 for(let sample=-3;sample<9;sample++){
  const compiled=engine.compile(definition);if(!compiled.ok)throw Error(JSON.stringify(compiled.diagnostics));
  const session=engine.createSession(compiled.form);
  const view=mount(root,session,{engine,views,themes:[baseTheme]});void root.offsetHeight;
  const input=root.querySelector('input');input.focus();
  const before=Object.values(session.debug.processorRuns).reduce((a,b)=>a+b,0);
  const started=performance.now();
  for(let edit=0;edit<25;edit++){session.setValue('field0',`Edit ${edit}`);void root.offsetHeight;}
  const elapsed=performance.now()-started;
  const processors=Object.values(session.debug.processorRuns).reduce((a,b)=>a+b,0)-before;
  if(processors!==(kind==='legacy'?650:25))throw Error(`Processor count ${processors}`);
  if(root.querySelector('input')!==input||document.activeElement!==input||root.querySelectorAll('input').length!==count)throw Error('Identity/focus/count regression');
  view.unmount();session.dispose();if(root.childNodes.length)throw Error('Leaked DOM');
  if(sample>=0)samples.push(elapsed);
 }
 return {count,kind,edit25Ms:median(samples),perEditMs:median(samples)/25,samples,processorRuns:kind==='legacy'?650:25};
};
