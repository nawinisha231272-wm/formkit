import {createEngine} from '@ourform/core';
import {createLogic} from '@ourform/core/logic';
import {builtinFields} from '@ourform/components';
import {validateSubmission} from '@ourform/validation';
const engine=createEngine({logic:createLogic()});
for(const field of builtinFields) engine.register(field.model);
const numeric=builtinFields.find(f=>f.model.type==='number').model;
engine.register({...numeric,type:'strict-number',value:{...numeric.value,normalize(value){if(value!==null && typeof value!=='number')throw new TypeError('Expected number');return value;}}});
const result=engine.compile({$formVersion:'1.0',id:'invalid-calculation',display:'form',components:[
{id:'source',key:'source',type:'text',label:'Source'},
{id:'target',key:'target',type:'strict-number',label:'Target'},
{id:'other',key:'other',type:'text',label:'Other'},
],logic:[{id:'derive',trigger:{on:'change'},then:[{action:'calculate',target:'target',expr:['if',['eq',{ref:'source'},'bad'],'not-a-number',2]}]}]});
if(!result.ok) throw Error(JSON.stringify(result.diagnostics));
const session=engine.createSession(result.form);
let diagnostics=[];session.subscribe(p=>{diagnostics=(p.diagnostics??[]).map(d=>d.code);});
session.setValue('source','bad');
const afterInvalid={data:session.getData(),diagnostics:[...diagnostics]};
session.setValue('other','edited');
const afterUnrelated={data:session.getData(),diagnostics:[...diagnostics]};
const browser=await session.submit();
const node=await validateSubmission(result.form,session.getData());
console.log(JSON.stringify({afterInvalid,afterUnrelated,browser,node},null,2));session.dispose();
