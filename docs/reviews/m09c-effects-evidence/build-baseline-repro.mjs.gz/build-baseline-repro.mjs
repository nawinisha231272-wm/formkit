import {build} from 'esbuild';
import {resolve} from 'node:path';
import {readFileSync} from 'node:fs';
const dir='.git/ourform-m09c-effects-2026-11-12';
await build({stdin:{contents:readFileSync(`${dir}/repro-invalid-calculation.mjs`,'utf8'),resolveDir:process.cwd()},bundle:true,platform:'node',format:'esm',target:'node22',outfile:`${dir}/baseline-invalid-calculation.mjs`,plugins:[{name:'exact-pushed-core',setup(ctx){ctx.onResolve({filter:/^@ourform\/core(\/logic)?$/},({path})=>({path:resolve(dir,'baseline-source/packages/core/src',path.endsWith('/logic')?'logic/index.ts':'index.ts')}));}}]});
